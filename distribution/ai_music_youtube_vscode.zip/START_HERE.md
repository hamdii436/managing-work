﻿# AI Music + YouTube automation (VS Code)

## Start here
1. Extract this ZIP to a normal folder (do not run it from inside the ZIP).
2. Open that folder in VS Code: **File > Open Folder**.
3. Install Python 3.10+ and ffmpeg. Make sure `ffmpeg -version` works in a new terminal.
4. Open `.env.example`, fill the required values below, then save a copy named `.env`.
5. Double-click `run_once.cmd` for one run or `run_hourly.cmd` for hourly mode.

## Required `.env` values
- `GEMINI_API_KEY`: your Gemini API key.
- `MUSIC_GENRE`: genre to create (e.g. `lofi`, `ambient`).
- `MUSIC_API_URL`: HTTPS base URL for a real music provider implementing the contract below.
- `CONTENT_IMAGE_PATH`: path to an existing image for the video, e.g. `cover.jpg`.

The initial launchers create a Python virtual environment and install this package's small `requirements.txt` if needed. If PowerShell blocks venv activation, the launchers call its Python executable directly.

## Music provider contract
No audio vendor is bundled or selected. The adapter sends `POST {MUSIC_API_URL}/jobs` with `{"prompt":"..."}`. It expects `{"id":"job-id"}` and polls `GET {MUSIC_API_URL}/jobs/{job-id}` until the response is `{"status":"completed","audio_url":"https://..."}`. Configure `MUSIC_API_TOKEN` if your provider requires a bearer token. Adapt `automation/providers/music.py` if the provider uses another API shape.

## YouTube (optional; disabled by default)
Uploads stay disabled unless you explicitly set `PUBLISH_ENABLED=true`. Privacy defaults to `private`. For publishing, configure `YOUTUBE_CLIENT_ID`, `YOUTUBE_CLIENT_SECRET`, and `YOUTUBE_REFRESH_TOKEN` for a channel-owner **user OAuth** flow. Service-account upload is not assumed. Optional settings: `YOUTUBE_PLAYLIST_ID`, `YOUTUBE_API_KEY` (keyword discovery), and `THUMBNAIL_IMAGE_PATH` (an image you already have). Never share or commit `.env`.

Set `SCHEDULER_ENABLED=true` to enable hourly scheduling. Default daily content limit is 8; `DAILY_CONTENT_LIMIT` accepts 1-10. Set `YOUTUBE_PRIVACY_STATUS=private` (default), `unlisted`, or `public` deliberately.

## Truthful limitations
- Gemini Pro generates text metadata (music prompt, titles, description, tags, thumbnail prompt, SEO keywords); it does not generate audio or thumbnail images.
- The audio comes from your configured external provider. Check its licensing and commercial-use terms yourself; this project makes no rights guarantee.
- Keyword discovery summarizes terms from recent, high-view YouTube search results; it is not reliable search-volume or trend data.
- YouTube has no native title A/B endpoint used here. The scaffold rotates titles in full UTC-day periods and compares Analytics views/watch-time metrics; it is sequential, not randomized, and does not report title CTR.
- The scheduler must stay running. The local SQLite database tracks hourly runs and the daily cap.

For a manual run in VS Code's terminal after setup:
```powershell
.\.venv\Scripts\python.exe scripts\run_hourly_pipeline.py --once
```
